export const coreApiUrl = 'http://mbpmedia.com/_api_rp';
