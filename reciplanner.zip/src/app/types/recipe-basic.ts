export class BasicRecipe {
  title: string;
  recipe_id: string;
  image_url: string;
  social_rank: number;
  source_url: string;
  publisher: string;
  publisher_url: string;
}
