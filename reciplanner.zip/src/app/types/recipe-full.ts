import { BasicRecipe } from './recipe-basic';

export class FullRecipe extends BasicRecipe {
  ingredients: Array<string>;
}
