export interface IAPIResponse {
  status: number;
  results: any;
}