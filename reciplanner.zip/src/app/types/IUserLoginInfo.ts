export interface IUserLoginInfo {
  username: string;
  password: string;
}
