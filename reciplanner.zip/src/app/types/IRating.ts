export interface IRating {
  id: string;
  rating: number;
}
